---
layout: page
title: About
permalink: /about/
---

Welcome to Natural Health Tips — your guide to a healthier, natural lifestyle.
